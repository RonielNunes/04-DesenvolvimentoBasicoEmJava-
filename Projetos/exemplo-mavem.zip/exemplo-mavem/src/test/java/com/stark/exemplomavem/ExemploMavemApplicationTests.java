package com.stark.exemplomavem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploMavemApplicationTests {

	@Test
	void contextLoads() {
	}

}
