package com.stark.exemplomavem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploMavemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploMavemApplication.class, args);
	}

}
